<?php
$sql = array();
$sql[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'pos_staticblock`';
$sql[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'pos_staticblock_lang`';
$sql[] = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'pos_staticblock_shop`';
